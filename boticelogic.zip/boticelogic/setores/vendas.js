const moment = require('moment');

module.exports = async function tratarVendas(texto, msg, sessao, db, bot, numero, sessoes) {
  const chatId = msg.chat.id;
  if (!sessao.subetapa) sessao.subetapa = null;
  const textoNormalizado = (texto || '').trim().toLowerCase();

  // Função auxiliar para enviar mensagens efêmeras
  async function sendEphemeralMessage(text, options = {}) {
    const sentMessage = await bot.sendMessage(chatId, text, {
      ...options,
      parse_mode: 'Markdown'
    });
    return sentMessage.message_id;
  }

  // Função para deletar mensagens
  async function deleteMessages(messageIds) {
    for (const messageId of messageIds) {
      try {
        await bot.deleteMessage(chatId, messageId);
      } catch (err) {
        console.error(`Erro ao deletar mensagem ${messageId}:`, err);
      }
    }
  }

  // Comandos gerais antes de iniciar o pedido
  if (!sessao.pedido) {
    if (textoNormalizado === 'laranja') {
      try {
        const [pixRows] = await db.query(
          "SELECT pix, qrcodex64 FROM laranja WHERE status = true LIMIT 1"
        );
        if (!pixRows.length) {
          const messageId = await sendEphemeralMessage('⚠️ Nenhum QR Code ativo encontrado.');
          setTimeout(() => deleteMessages([messageId]), 5000);
          return;
        }
        const pixMessageId = await sendEphemeralMessage(`🟠 PIX: ${pixRows[0].pix}`);
        const qrMessageId = await bot.sendPhoto(chatId, Buffer.from(pixRows[0].qrcodex64, 'base64'), {
          caption: '🧾 QR Code PIX'
        }).then(sent => sent.message_id);
        await deleteMessages([msg.message_id]);
        setTimeout(() => deleteMessages([pixMessageId, qrMessageId]), 30000);
        return;
      } catch (err) {
        console.error('Erro ao buscar PIX:', err);
        const messageId = await sendEphemeralMessage('⚠️ Erro ao obter QR Code.');
        setTimeout(() => deleteMessages([messageId]), 5000);
        return;
      }
    }

    if (textoNormalizado === 'lista') {
      try {
        const [produtos] = await db.query(
          'SELECT nome, categoria, icone_categoria, valor_unitario FROM estoque ORDER BY categoria, nome'
        );
        if (!produtos.length) {
          const messageId = await sendEphemeralMessage('📦 Nenhum produto em estoque.');
          setTimeout(() => deleteMessages([messageId]), 5000);
          return;
        }

        const categorias = {};
        const icones = {};

        for (const produto of produtos) {
          const categoria = produto.categoria || 'Sem categoria';
          if (!categorias[categoria]) categorias[categoria] = [];
          if (!icones[categoria]) icones[categoria] = produto.icone_categoria || '📦';
          const preco = parseFloat(produto.valor_unitario) || 0;
          categorias[categoria].push(`${produto.nome} - R$ ${preco.toFixed(2)}`);
        }

        let resposta = [
          '🏌🏼‍♂️'.repeat(13),
          '**FAVOR, LEIA COM ATENÇÃO!**',
          '**NÃO REPASSE A LISTA!**',
          '**ATENDIMENTO DE SEGUNDA A SÁBADO, DAS 08:00 às 22:00!**',
          '**EVITE PIX! PREFERÊNCIA NO DINHEIRO!**',
          '**PIX SÓ ANTECIPADO! FAVOR ENVIAR O COMPROVANTE!**',
          '**ANTES DE FAZER O PIX PEÇA A CHAVE!**',
          '**PEDIDO MÍNIMO R$50,00!**',
          '**APENAS PEDIDO ANTECIPADO, NÃO ATENDEMOS A PRONTA ENTREGA!**',
          '**HORÁRIO DE ENTREGA VARIÁVEL!**',
          '**ENTREGA GRÁTIS**\n'
        ];

        for (const [categoria, itens] of Object.entries(categorias)) {
          resposta.push(`\n${icones[categoria]} *${categoria}*`);
          resposta.push(...itens.map(item => `• ${item}`));
        }

        resposta.push('\n' + '🏌🏼‍♂️'.repeat(13));
        resposta.push('**FAVOR, LEIA COM ATENÇÃO!**');
        resposta.push('**NÃO REPASSE A LISTA!**');
        resposta.push('**ATENDIMENTO DE SEGUNDA A SÁBADO, DAS 08:00 às 23:00!**');
        resposta.push('**EVITE PIX! PREFERÊNCIA NO DINHEIRO!**');
        resposta.push('**PIX SÓ ANTECIPADO! FAVOR ENVIAR O COMPROVANTE!**');
        resposta.push('**ANTES DE FAZER O PIX PEÇA A CHAVE!**');
        resposta.push('**PEDIDO MÍNIMO R$50,00!**');
        resposta.push('**APENAS PEDIDO ANTECIPADO, NÃO ATENDEMOS A PRONTA ENTREGA!**');
        resposta.push('**HORÁRIO DE ENTREGA VARIÁVEL!**');
        resposta.push('**ENTREGA GRÁTIS**');

        const messageId = await sendEphemeralMessage(resposta.join('\n'));
        await deleteMessages([msg.message_id]);
        setTimeout(() => deleteMessages([messageId]), 60000);
        return;
      } catch (err) {
        console.error('Erro ao gerar lista:', err);
        const messageId = await sendEphemeralMessage('⚠️ Erro ao gerar a lista de produtos.');
        setTimeout(() => deleteMessages([messageId]), 5000);
        return;
      }
    }

    if (textoNormalizado === 'pedidos') {
      try {
        const [pedidos] = await db.query(
          "SELECT id, cliente_numero, itens, status FROM vendas WHERE status IN ('novo','embalado')"
        );
        if (!pedidos.length) {
          const messageId = await sendEphemeralMessage('📭 Nenhum pedido em andamento.');
          setTimeout(() => deleteMessages([messageId]), 5000);
          return;
        }
        for (const p of pedidos) {
          const messageId = await sendEphemeralMessage(
            `🧾 Pedido ${p.id}\n📞 Cliente: ${p.cliente_numero}\n🛍️ Itens: ${p.itens}\n📌 Status: ${p.status}`
          );
          setTimeout(() => deleteMessages([messageId]), 10000);
        }
        await deleteMessages([msg.message_id]);
        return;
      } catch (err) {
        console.error('Erro ao listar pedidos:', err);
        const messageId = await sendEphemeralMessage('⚠️ Erro ao listar pedidos.');
        setTimeout(() => deleteMessages([messageId]), 5000);
        return;
      }
    }

    if (textoNormalizado.startsWith('info ')) {
      const termo = textoNormalizado.substring(5).trim();
      try {
        const [produtos] = await db.query(
          'SELECT * FROM estoque WHERE LOWER(nome) LIKE ?',
          [`%${termo}%`]
        );
        if (!produtos.length) {
          const messageId = await sendEphemeralMessage('❌ Produto não encontrado.');
          setTimeout(() => deleteMessages([messageId]), 5000);
          return;
        }
        const item = produtos[0];
        let info = ` *${item.nome}*\n📏 ${item.quantidade} ${item.medida}` +
                   `\n🗓️ Recebido em: ${moment(item.data_recebimento).format('DD/MM/YYYY')}`;
        if (item.info_extra) info += `\n📝 ${item.info_extra}`;
        const textMessageId = await sendEphemeralMessage(info);
        if (item.imagem) {
          const imageMessageId = await bot.sendPhoto(chatId, Buffer.from(item.imagem, 'base64'), {
            caption: '📷 Produto'
          }).then(sent => sent.message_id);
          setTimeout(() => deleteMessages([textMessageId, imageMessageId]), 30000);
        } else {
          setTimeout(() => deleteMessages([textMessageId]), 30000);
        }
        await deleteMessages([msg.message_id]);
        return;
      } catch (err) {
        console.error('Erro ao buscar info:', err);
        const messageId = await sendEphemeralMessage('⚠️ Erro ao obter informações do produto.');
        setTimeout(() => deleteMessages([messageId]), 5000);
        return;
      }
    }

    if (msg.contact) {
      const numeroBruto = msg.contact.phone_number.replace(/\D/g, '');
      if (!numeroBruto) {
        const messageId = await sendEphemeralMessage('❌ Não consegui ler o número do contato.');
        setTimeout(() => deleteMessages([messageId]), 5000);
        return;
      }
      const numeroCompleto = numeroBruto.startsWith('55') ? numeroBruto : '55' + numeroBruto;
      const numeroFormatado = numeroCompleto; // Telegram usa IDs, mas mantemos o formato para compatibilidade
      sessao.pedido = { cliente: numeroFormatado, itens: [], etapa: 'itens' };
      sessoes.set(numero, sessao);
      const messageId = await sendEphemeralMessage(
        `📲 Cliente definido como *${numeroCompleto}*.\nAgora envie o produto (nome ou ID).`
      );
      await deleteMessages([msg.message_id]);
      setTimeout(() => deleteMessages([messageId]), 10000);
      return;
    }

    if (/^[0-9]{8,13}$/.test(textoNormalizado)) {
      const numeric = textoNormalizado;
      const numeroCompleto = numeric.startsWith('55') ? numeric : '55' + numeric;
      const numeroFormatado = numeroCompleto;
      sessao.pedido = { cliente: numeroFormatado, itens: [], etapa: 'itens' };
      sessoes.set(numero, sessao);
      const messageId = await sendEphemeralMessage(
        `📲 Cliente definido como *${numeroCompleto}*.\nAgora envie o produto (nome ou ID).`
      );
      await deleteMessages([msg.message_id]);
      bot.once('message', async (response) => {
        await deleteMessages([messageId, response.message_id]);
      });
      return;
    }

    const messageId = await sendEphemeralMessage(
      '🛍️ Setor de VENDAS ativo. Use "laranja", "lista", "info [produto]" ou envie um contato/número para iniciar um pedido.'
    );
    await deleteMessages([msg.message_id]);
    setTimeout(() => deleteMessages([messageId]), 10000);
    return;
  }

  // Pedido em andamento
  if (sessao.pedido.etapa === 'itens') {
    if (textoNormalizado === 'finalizar') {
      if (!sessao.pedido.itens.length) {
        const messageId = await sendEphemeralMessage('❌ Você ainda não adicionou nenhum item.');
        setTimeout(() => deleteMessages([messageId]), 5000);
        return;
      }
      let valorTotal = 0;
      for (const desc of sessao.pedido.itens) {
        const [nomeItem, quantUn] = desc.split(' - ');
        const quantidade = parseFloat(quantUn);
        const [rows] = await db.query(
          'SELECT valor_unitario FROM estoque WHERE LOWER(nome) = ?',
          [nomeItem.toLowerCase()]
        );
        if (rows.length) valorTotal += quantidade * parseFloat(rows[0].valor_unitario);
      }
      sessao.pedido.valorTotal = valorTotal;
      sessao.pedido.etapa = 'pagamento';
      sessoes.set(numero, sessao);
      const resumo = sessao.pedido.itens.map(i => `• ${i}`).join('\n');
      const messageId = await sendEphemeralMessage(
        `✅ Itens registrados:\n${resumo}\n\n💳 Como será o pagamento?`,
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: 'Pix', callback_data: 'pagamento_pix' }],
              [{ text: 'Dinheiro', callback_data: 'pagamento_dinheiro' }],
              [{ text: 'Pix e Dinheiro', callback_data: 'pagamento_pix_dinheiro' }]
            ]
          }
        }
      );
      await deleteMessages([msg.message_id]);
      return;
    }

    if (!sessao.pedido.awaitingQuantidade) {
      const termo = texto.trim();
      const isId = /^[0-9]+$/.test(termo);
      const query = isId
        ? 'SELECT id,nome FROM estoque WHERE id = ?'
        : 'SELECT id,nome FROM estoque WHERE LOWER(nome) = ?';
      const [rows] = await db.query(query, [isId ? termo : termo.toLowerCase()]);
      if (!rows.length) {
        const messageId = await sendEphemeralMessage(`❌ Produto "${termo}" não encontrado no estoque.`);
        setTimeout(() => deleteMessages([messageId]), 5000);
        return;
      }
      sessao.pedido.produtoTemp = { id: rows[0].id, nome: rows[0].nome };
      sessao.pedido.awaitingQuantidade = true;
      sessoes.set(numero, sessao);
      const messageId = await sendEphemeralMessage(
        `📦 Produto: *${rows[0].nome}*\nInforme a quantidade e unidade (ex: 2 kg, 5 un):`
      );
      await deleteMessages([msg.message_id]);
      bot.once('message', async (response) => {
        await deleteMessages([messageId, response.message_id]);
      });
      return;
    }

    if (sessao.pedido.awaitingQuantidade) {
      const match = texto.trim().toLowerCase().match(/^([\d.,]+)\s*(kg|g|un|l|ml)$/);
      if (!match) {
        const messageId = await sendEphemeralMessage('⚠️ Formato inválido. Use algo como: `2 kg`, `5 un`, `1.5 l`');
        bot.once('message', async (response) => {
          await deleteMessages([messageId, response.message_id]);
        });
        return;
      }
      const quantidade = parseFloat(match[1].replace(',', '.'));
      const unidade = match[2];
      const descricao = `${sessao.pedido.produtoTemp.nome} - ${quantidade} ${unidade}`;
      sessao.pedido.itens.push(descricao);
      delete sessao.pedido.produtoTemp;
      delete sessao.pedido.awaitingQuantidade;
      sessoes.set(numero, sessao);
      const messageId = await sendEphemeralMessage(
        `➕ Adicionado: ${descricao}\nDigite mais itens ou "finalizar".`
      );
      await deleteMessages([msg.message_id]);
      setTimeout(() => deleteMessages([messageId]), 10000);
      return;
    }
  }

  if (sessao.pedido.etapa === 'pix' && msg.photo) {
    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const file = await bot.getFile(fileId);
    const fileStream = bot.getFileStream(fileId);
    const chunks = [];
    for await (const chunk of fileStream) {
      chunks.push(chunk);
    }
    sessao.pedido.comprovante = Buffer.concat(chunks);
    sessao.pedido.etapa = 'endereco';
    sessoes.set(numero, sessao);
    const messageId = await sendEphemeralMessage('📍 Informe o endereço: rua, número, bairro.');
    await deleteMessages([msg.message_id]);
    bot.once('message', async (response) => {
      await deleteMessages([messageId, response.message_id]);
    });
    return;
  }

  if (sessao.pedido.etapa === 'pix_misto' && msg.photo) {
    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const file = await bot.getFile(fileId);
    const fileStream = bot.getFileStream(fileId);
    const chunks = [];
    for await (const chunk of fileStream) {
      chunks.push(chunk);
    }
    sessao.pedido.comprovante = Buffer.concat(chunks);
    sessao.pedido.etapa = 'dinheiro_misto';
    sessoes.set(numero, sessao);
    const messageId = await sendEphemeralMessage('💰 Agora informe o valor pago em dinheiro.');
    await deleteMessages([msg.message_id]);
    bot.once('message', async (response) => {
      await deleteMessages([messageId, response.message_id]);
    });
    return;
  }

  if ((sessao.pedido.etapa === 'dinheiro' || sessao.pedido.etapa === 'dinheiro_misto') && !isNaN(parseFloat(texto))) {
    sessao.pedido.valor = parseFloat(texto.replace(',', '.'));
    sessao.pedido.etapa = 'endereco';
    sessoes.set(numero, sessao);
    const messageId = await sendEphemeralMessage('📍 Informe o endereço: rua, número, bairro.');
    await deleteMessages([msg.message_id]);
    bot.once('message', async (response) => {
      await deleteMessages([messageId, response.message_id]);
    });
    return;
  }

  if (sessao.pedido.etapa === 'endereco') {
    sessao.pedido.endereco = texto;
    const valorFinal = sessao.pedido.valorTotal || sessao.pedido.valor || 0;
    const itensJson = JSON.stringify(sessao.pedido.itens);
    const vendedor = numero;
    try {
      const [vendedorRows] = await db.query(
        'SELECT id FROM usuarios WHERE numero = ? LIMIT 1',
        [vendedor]
      );
      const vendedorId = vendedorRows.length ? vendedorRows[0].id : null;

      const [result] = await db.query(
        `INSERT INTO vendas 
         (cliente_numero, itens, forma_pagamento, comprovante, valor_pago, endereco, recebido, status, vendedor_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          sessao.pedido.cliente,
          itensJson,
          sessao.pedido.forma,
          sessao.pedido.comprovante || null,
          valorFinal,
          sessao.pedido.endereco,
          false,
          'novo',
          vendedorId
        ]
      );

      const vendaId = result.insertId;

      await db.query(
        'INSERT INTO pedidos_diarios (cliente_numero, itens, endereco, recebido, status, venda_id) VALUES (?, ?, ?, ?, ?, ?)',
        [
          sessao.pedido.cliente,
          itensJson,
          sessao.pedido.endereco,
          false,
          'novo',
          vendaId
        ]
      );
    } catch (err) {
      console.error('Erro ao salvar pedido:', err);
      const messageId = await sendEphemeralMessage('⚠️ Erro ao registrar o pedido. Tente novamente mais tarde.');
      setTimeout(() => deleteMessages([messageId]), 5000);
      return;
    }

    delete sessao.pedido;
    sessoes.set(numero, sessao);
    const messageId = await sendEphemeralMessage('🧾 Pedido registrado com sucesso!');
    await deleteMessages([msg.message_id]);
    setTimeout(() => deleteMessages([messageId]), 5000);
    return;
  }

  // Manipula escolhas de pagamento via botões
  bot.on('callback_query', async (query) => {
    const queryChatId = query.message.chat.id;
    if (queryChatId !== chatId) return;
    const messageId = query.message.message_id;
    const data = query.data;

    if (data.startsWith('pagamento_')) {
      const formas = {
        'pagamento_pix': 'pix',
        'pagamento_dinheiro': 'dinheiro',
        'pagamento_pix_dinheiro': 'pix e dinheiro'
      };
      sessao.pedido.forma = formas[data];
      sessoes.set(numero, sessao);

      if (data === 'pagamento_pix') {
        sessao.pedido.etapa = 'pix';
        await bot.editMessageText('📎 Envie o comprovante em imagem.', {
          chat_id: chatId,
          message_id: messageId
        });
        bot.once('message', async (response) => {
          await deleteMessages([messageId, response.message_id]);
        });
      } else if (data === 'pagamento_dinheiro') {
        sessao.pedido.etapa = 'dinheiro';
        await bot.editMessageText('💰 Informe o valor pago em dinheiro.', {
          chat_id: chatId,
          message_id: messageId
        });
        bot.once('message', async (response) => {
          await deleteMessages([messageId, response.message_id]);
        });
      } else if (data === 'pagamento_pix_dinheiro') {
        sessao.pedido.etapa = 'pix_misto';
        await bot.editMessageText('📎 Envie o comprovante do valor pago em PIX.', {
          chat_id: chatId,
          message_id: messageId
        });
        bot.once('message', async (response) => {
          await deleteMessages([messageId, response.message_id]);
        });
      }
      await bot.answerCallbackQuery(query.id);
    }
  });

  const messageId = await sendEphemeralMessage(
    '🛍️ Setor de VENDAS ativo. Use "lista", "info [produto]" ou envie mais comandos conforme instruções.'
  );
  await deleteMessages([msg.message_id]);
  setTimeout(() => deleteMessages([messageId]), 10000);
};