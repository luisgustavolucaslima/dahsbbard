const TelegramBot = require('node-telegram-bot-api');
const mysql = require('mysql2/promise');
const moment = require('moment');
const axios = require('axios');
require('dotenv').config();

const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY || 'AIzaSyBpqMDBX4ic49y85K4-3dNJyxkZwD2rZ9c';
const SENHA_MESTRE = '#acesso123';
const tratarEstoque = require('./setores/estoque');
const tratarEntrega = require('./setores/entrega');
const tratarVendas = require('./setores/vendas');

const bot = new TelegramBot(process.env.TELEGRAM_TOKEN, { polling: true });
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'iceclubestoque'
});

const sessoes = new Map(); // Controle de sessão ativa

// Função para enviar mensagens efêmeras
async function sendEphemeralMessage(chatId, text, options = {}) {
  const sentMessage = await bot.sendMessage(chatId, text, {
    ...options,
    parse_mode: 'Markdown'
  });
  return sentMessage.message_id;
}

// Função para deletar mensagens
async function deleteMessages(chatId, messageIds) {
  for (const messageId of messageIds) {
    try {
      await bot.deleteMessage(chatId, messageId);
    } catch (err) {
      console.error(`Erro ao deletar mensagem ${messageId}:`, err);
    }
  }
}

// Evento principal de mensagens
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const numero = String(msg.from.id); // Usar Telegram ID como identificador
  const hoje = moment().format('YYYY-MM-DD');
  const texto = (msg.text || '').trim();
  const [usuarios] = await db.query('SELECT * FROM usuarios WHERE numero = ?', [numero]);

  let sessao = sessoes.get(numero) || { setor: null, data: hoje, autenticado: false, logado: false };

  // Reseta sessão se for de outro dia
  if (sessao.data !== hoje) {
    sessao = { setor: null, data: hoje, autenticado: false, logado: false };
    sessoes.set(numero, sessao);
  }

  // Novo usuário
  if (!usuarios.length) {
    if (texto !== SENHA_MESTRE) {
      const messageId = await sendEphemeralMessage(chatId, '🔒 Envie a senha de acesso para registrar-se.');
      bot.once('message', async (response) => {
        await deleteMessages(chatId, [messageId, response.message_id]);
      });
      return;
    }
    await db.query('INSERT INTO usuarios (numero, nome, senha, ultima_sessao) VALUES (?, ?, ?, ?)', [numero, numero, null, hoje]);
    sessoes.set(numero, sessao);
    const messageId = await sendEphemeralMessage(chatId, '✅ Acesso liberado! Agora, envie sua senha pessoal para completar o cadastro.');
    bot.once('message', async (response) => {
      await deleteMessages(chatId, [messageId, response.message_id]);
    });
    return;
  }

  const usuario = usuarios[0];

  // Usuário existe mas sem senha
  if (!usuario.senha) {
    if (texto.length < 4) {
      const messageId = await sendEphemeralMessage(chatId, '❗ A senha deve ter pelo menos 4 caracteres.');
      bot.once('message', async (response) => {
        await deleteMessages(chatId, [messageId, response.message_id]);
      });
      return;
    }
    await db.query('UPDATE usuarios SET senha = ?, ultima_sessao = ? WHERE numero = ?', [texto, hoje, numero]);
    sessoes.set(numero, sessao);
    const messageId = await sendEphemeralMessage(chatId, '✅ Conta criada com sucesso!\n🔓 Escolha um setor:', {
      reply_markup: {
        inline_keyboard: [
          [{ text: '1️⃣ Entrega', callback_data: 'setor_1' }],
          [{ text: '2️⃣ Estoque', callback_data: 'setor_2' }],
          [{ text: '3️⃣ Vendas', callback_data: 'setor_3' }]
        ]
      }
    });
    return;
  }

  // Verificação de senha pessoal
  if (!sessao.logado) {
    if (texto !== usuario.senha) {
      const messageId = await sendEphemeralMessage(chatId, '❌ Senha incorreta. Envie sua senha pessoal para acessar.');
      bot.once('message', async (response) => {
        await deleteMessages(chatId, [messageId, response.message_id]);
      });
      return;
    }
    sessao.logado = true;
    sessoes.set(numero, sessao);
    const messageId = await sendEphemeralMessage(chatId, '🔓 Login diário realizado!\n\nEscolha:', {
      reply_markup: {
        inline_keyboard: [
          [{ text: '1️⃣ Entrega', callback_data: 'setor_1' }],
          [{ text: '2️⃣ Estoque', callback_data: 'setor_2' }],
          [{ text: '3️⃣ Vendas', callback_data: 'setor_3' }]
        ]
      }
    });
    return;
  }

  // Sair
  if (texto.toLowerCase() === 'sair') {
    sessoes.delete(numero);
    const messageId = await sendEphemeralMessage(chatId, '🛑 Você saiu do fluxo. Para começar de novo, envie "oi".');
    setTimeout(() => deleteMessages(chatId, [messageId]), 5000);
    return;
  }

  // Verifica se escolheu setor
  if (!sessao.setor) {
    const messageId = await sendEphemeralMessage(chatId, 'ℹ️ Escolha um setor para continuar:', {
      reply_markup: {
        inline_keyboard: [
          [{ text: '1️⃣ Entrega', callback_data: 'setor_1' }],
          [{ text: '2️⃣ Estoque', callback_data: 'setor_2' }],
          [{ text: '3️⃣ Vendas', callback_data: 'setor_3' }]
        ]
      }
    });
    return;
  }

  // Autenticação do setor
  const senhasSetor = { entrega: 'entrega123', estoque: 'estoque123', vendas: 'venda123' };
  if (!sessao.autenticado) {
    if (texto === senhasSetor[sessao.setor]) {
      sessao.autenticado = true;
      sessoes.set(numero, sessao);
      const messageId = await sendEphemeralMessage(chatId, `✅ Acesso ao setor *${sessao.setor.toUpperCase()}* liberado.`);
      setTimeout(() => deleteMessages(chatId, [messageId]), 5000);
    } else {
      const messageId = await sendEphemeralMessage(chatId, `🔐 Envie a senha correta do setor *${sessao.setor.toUpperCase()}* para acessar.`);
      bot.once('message', async (response) => {
        await deleteMessages(chatId, [messageId, response.message_id]);
      });
    }
    return;
  }

  // Executa o fluxo do setor
  try {
    switch (sessao.setor) {
      case 'vendas':
        await tratarVendas(texto, msg, sessao, db, bot, numero, sessoes);
        break;
      case 'estoque':
        await tratarEstoque(texto, msg, sessao, db, bot);
        break;
      case 'entrega':
        await tratarEntrega(texto, msg, sessao, db, bot, numero, sessoes);
        break;
      default:
        const messageId = await sendEphemeralMessage(chatId, '❓ Setor inválido. Escolha um setor:', {
          reply_markup: {
            inline_keyboard: [
              [{ text: '1️⃣ Entrega', callback_data: 'setor_1' }],
              [{ text: '2️⃣ Estoque', callback_data: 'setor_2' }],
              [{ text: '3️⃣ Vendas', callback_data: 'setor_3' }]
            ]
          }
        });
    }
  } catch (err) {
    console.error('Erro no setor:', err);
    const messageId = await sendEphemeralMessage(chatId, '⚠️ Ocorreu um erro ao processar sua solicitação.');
    setTimeout(() => deleteMessages(chatId, [messageId]), 5000);
  }
});

// Manipula escolhas de setor via botões
bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const numero = String(query.from.id);
  const messageId = query.message.message_id;
  const data = query.data;

  let sessao = sessoes.get(numero);
  if (!sessao) return;

  if (data.startsWith('setor_')) {
    if (sessao.autenticado) {
      await bot.editMessageText('⚠️ Você já está autenticado em um setor. Envie "sair" para reiniciar.', {
        chat_id: chatId,
        message_id: messageId
      });
      setTimeout(() => deleteMessages(chatId, [messageId]), 5000);
      return;
    }
    const setores = { 'setor_1': 'entrega', 'setor_2': 'estoque', 'setor_3': 'vendas' };
    sessao.setor = setores[data];
    sessoes.set(numero, sessao);
    await bot.editMessageText(`🔑 Setor selecionado: *${sessao.setor.toUpperCase()}*\nEnvie a senha do setor para continuar.`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'Markdown'
    });
    bot.once('message', async (response) => {
      await deleteMessages(chatId, [messageId, response.message_id]);
    });
    await bot.answerCallbackQuery(query.id);
  }
});

console.log('✅ Bot Telegram iniciado!');